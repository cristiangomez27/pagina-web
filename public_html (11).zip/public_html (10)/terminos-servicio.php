<?php
require_once __DIR__ . '/includes/web_helpers.php';
$data = sw_load_data();
$negocio = $data['negocio'] ?? [];
$title = sw_page_title($data, 'Términos de servicio');
$nombre = (string)($negocio['nombre'] ?? 'Suave Urban Studio');
$correo = trim((string)($negocio['correo'] ?? ''));
$telefono = trim((string)($negocio['telefono'] ?? ''));
$whatsapp = trim((string)($negocio['whatsapp'] ?? ''));
$direccion = trim((string)($negocio['direccion'] ?? ''));
$custom = trim((string)($data['legales']['terminos_servicio'] ?? ''));
require __DIR__ . '/includes/web_header.php';
?>
<section class="page-title legal-title">
    <p>Información legal</p>
    <h1>Términos de servicio</h1>
    <span>Última actualización: <?= sw_e(date('d/m/Y')) ?></span>
</section>

<section class="clean-panel legal-page">
<?php if ($custom !== ''): ?>
    <div class="legal-content"><?= nl2br(sw_e($custom)) ?></div>
<?php else: ?>
    <p>Al navegar, crear una cuenta, agregar productos al carrito, solicitar información o realizar una compra en la tienda en línea de <strong><?= sw_e($nombre) ?></strong>, el cliente acepta los presentes Términos de Servicio. Estos términos aplican a la venta de productos, prendas y artículos de la marca Suave Urban Studio publicados en la web.</p>

    <h2>1. Naturaleza de la tienda</h2>
    <p>Esta web está orientada a la venta de productos de la marca Suave Urban Studio. Los productos mostrados forman parte del catálogo publicado por la Tienda y están sujetos a disponibilidad, actualización de inventario, cambios de temporada, promociones o ajustes comerciales.</p>

    <h2>2. Uso correcto de la web</h2>
    <p>El cliente se compromete a utilizar la tienda de forma lícita, respetuosa y conforme a estos términos. La Tienda podrá limitar, suspender o cancelar operaciones cuando detecte uso indebido, información falsa, intentos de fraude, abuso de promociones o conductas que afecten la operación normal del sitio.</p>

    <h2>3. Productos, imágenes y disponibilidad</h2>
    <ul>
        <li>Las imágenes de productos son ilustrativas y se muestran para representar el artículo de la mejor manera posible.</li>
        <li>Los colores, tonos, texturas, medidas, acomodos o acabados pueden variar ligeramente por iluminación, pantalla, edición fotográfica, disponibilidad de materiales o lote de fabricación.</li>
        <li>Los productos están sujetos a disponibilidad. Si un producto deja de estar disponible después de una compra, la Tienda podrá ofrecer cambio, espera, saldo a favor o reembolso según corresponda.</li>
        <li>La Tienda puede actualizar catálogo, fotografías, precios, descripciones, modelos o promociones sin previo aviso.</li>
    </ul>

    <h2>4. Precios y promociones</h2>
    <p>Los precios se muestran en pesos mexicanos, salvo que se indique algo distinto. Las promociones, descuentos, paquetes o beneficios pueden tener vigencia limitada, condiciones especiales o estar sujetos a disponibilidad. En caso de error evidente de precio, publicación o captura, la Tienda podrá corregirlo y contactar al cliente antes de procesar el pedido.</p>

    <h2>5. Pagos y confirmación de pedido</h2>
    <p>El pedido se considera confirmado únicamente cuando el pago haya sido validado por la Tienda o por el medio de pago correspondiente. Si el pago no se confirma, el pedido puede quedar pendiente, pausado o cancelado. La Tienda puede solicitar comprobante, aclaración o validación adicional cuando lo considere necesario para proteger la operación y evitar fraudes.</p>

    <h2>6. Datos del pedido</h2>
    <p>Antes de confirmar la compra, el cliente debe revisar cuidadosamente modelo, talla, color, cantidad, dirección de entrega, datos de contacto y cualquier información relacionada con su pedido. La Tienda no será responsable por errores derivados de información incorrecta, incompleta o desactualizada proporcionada por el cliente.</p>

    <h2>7. Envíos y entregas</h2>
    <ul>
        <li>Las fechas de entrega son estimadas y pueden variar por carga operativa, disponibilidad, zona de entrega, clima, logística, paquetería o causas externas.</li>
        <li>La Tienda dará seguimiento al pedido, pero no controla totalmente los tiempos, rutas, incidencias o políticas de terceros como paqueterías o plataformas de entrega.</li>
        <li>El cliente debe estar disponible en los medios de contacto proporcionados para aclaraciones, confirmación de domicilio o coordinación de entrega.</li>
        <li>Si la entrega no puede completarse por datos incorrectos, ausencia del cliente o falta de respuesta, podrían generarse costos adicionales de reenvío o reprogramación.</li>
    </ul>

    <h2>8. Cambios</h2>
    <p>Los cambios pueden aceptarse conforme a disponibilidad y condiciones de la Tienda. Para solicitar un cambio, el producto debe estar sin uso, limpio, sin daños, con etiquetas, empaque o condiciones originales cuando aplique, y dentro del plazo informado por la Tienda. Los cambios por talla, modelo o color dependen de existencia disponible.</p>

    <h2>9. Devoluciones y aclaraciones</h2>
    <p>No se aceptan devoluciones por uso, maltrato, lavado inadecuado, desgaste normal, manipulación incorrecta, cambio de opinión fuera del plazo indicado, elección incorrecta de talla/modelo/color por parte del cliente o falta de revisión al momento de recibir. Si existe un defecto atribuible directamente a la Tienda, el caso será revisado y podrá ofrecerse cambio, reparación, saldo a favor o reembolso según corresponda.</p>

    <h2>10. Cuidado de prendas y productos</h2>
    <p>El cliente debe seguir las recomendaciones de cuidado, lavado, secado, planchado y uso del producto. La Tienda no será responsable por daños causados por lavado inadecuado, químicos, cloro, calor excesivo, planchado incorrecto, fricción, uso indebido o falta de cuidado.</p>

    <h2>11. Cuenta de cliente</h2>
    <p>El cliente es responsable de la información registrada en su cuenta, de mantener sus datos actualizados y de proteger sus accesos. Cualquier actividad realizada desde su cuenta podrá considerarse solicitada por el titular, salvo que se demuestre lo contrario.</p>

    <h2>12. Propiedad de marca y contenido</h2>
    <p>El nombre Suave Urban Studio, logotipos, fotografías, textos, gráficos, productos, diseños, elementos visuales, estructura del sitio y contenido publicado pertenecen a la Tienda o se utilizan con autorización. No está permitido copiar, reproducir, revender, extraer, modificar o usar el contenido de la marca sin autorización previa por escrito.</p>

    <h2>13. Servicios externos</h2>
    <p>La operación de la tienda puede apoyarse en servicios externos como hosting, Google Drive, WhatsApp, correo electrónico, pasarelas de pago, paqueterías o herramientas digitales. La Tienda no será responsable por interrupciones, fallas, retrasos o errores ocasionados directamente por dichos servicios externos, aunque procurará dar seguimiento cuando afecten una compra.</p>

    <h2>14. Cancelaciones</h2>
    <p>La Tienda puede cancelar o pausar pedidos cuando exista falta de pago, datos incompletos, sospecha de fraude, indisponibilidad del producto, error evidente en publicación o imposibilidad logística. En caso de cancelación procedente con pago confirmado, se informará al cliente la solución aplicable.</p>

    <h2>15. Actualizaciones de términos</h2>
    <p>La Tienda puede modificar estos Términos de Servicio para actualizar procesos, políticas, catálogo, formas de atención o requisitos operativos. La versión vigente estará publicada en esta página y aplicará desde su publicación.</p>

    <h2>16. Contacto</h2>
    <p>Para dudas, cambios, aclaraciones o seguimiento de pedidos, el cliente puede contactar a la Tienda mediante los canales publicados en la web.</p>
    <?php if ($correo !== ''): ?><p><strong>Correo:</strong> <?= sw_e($correo) ?></p><?php endif; ?>
    <?php if ($telefono !== ''): ?><p><strong>Teléfono:</strong> <?= sw_e($telefono) ?></p><?php endif; ?>
    <?php if ($whatsapp !== ''): ?><p><strong>WhatsApp:</strong> <?= sw_e($whatsapp) ?></p><?php endif; ?>
    <?php if ($direccion !== ''): ?><p><strong>Dirección o zona de atención:</strong> <?= nl2br(sw_e($direccion)) ?></p><?php endif; ?>

    <div class="legal-signature">
        <strong>Firma comercial</strong>
        <p><?= sw_e($nombre) ?></p>
        <span>Tienda oficial de la marca Suave Urban Studio</span>
        <span>Estos términos forman parte de la experiencia de compra dentro de la tienda en línea.</span>
    </div>
<?php endif; ?>
</section>

<style>
.legal-title span{display:inline-block;margin-top:10px;color:rgba(255,255,255,.58);font-size:13px}.legal-page{line-height:1.75;color:rgba(255,255,255,.82)}.legal-page h2{margin:28px 0 10px;color:var(--su-gold-soft);font-size:22px}.legal-page p{margin:0 0 14px}.legal-page ul{margin:0 0 16px 22px;padding:0}.legal-page li{margin:7px 0}.legal-signature{margin-top:34px;padding:20px;border:1px solid rgba(212,175,55,.22);border-radius:18px;background:linear-gradient(135deg,rgba(212,175,55,.10),rgba(255,255,255,.025));box-shadow:0 18px 45px rgba(0,0,0,.25)}.legal-signature strong{display:block;color:var(--su-gold);letter-spacing:.08em;text-transform:uppercase;font-size:12px;margin-bottom:10px}.legal-signature p{font-size:22px;font-weight:800;color:#fff;margin:0 0 4px}.legal-signature span{display:block;color:rgba(255,255,255,.68);font-size:14px;margin-top:4px}.legal-content{white-space:normal}
</style>
<?php require __DIR__ . '/includes/web_footer.php'; ?>
