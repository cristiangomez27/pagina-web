<?php
declare(strict_types=1);
require_once __DIR__ . '/ventas/config/database.php';

function rw_e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

$token = trim((string)($_GET['token'] ?? $_GET['t'] ?? ''));
if ($token === '') {
    http_response_code(403);
    echo '<h2>Enlace protegido. Para ver esta remisión necesitas un enlace válido.</h2>';
    exit;
}

$st = $conn->prepare("SELECT pw.*, wo.codigo, wo.cliente_nombre, wo.cliente_telefono, wo.cliente_correo, wo.cliente_direccion, wo.estado_pago, wo.created_at AS orden_fecha
    FROM pedidos_web pw
    INNER JOIN web_ordenes wo ON wo.id = pw.web_orden_id
    WHERE pw.remision_web_token = ?
    LIMIT 1");
$st->bind_param('s', $token);
$st->execute();
$pedido = $st->get_result()->fetch_assoc();

if (!$pedido) {
    http_response_code(403);
    echo '<h2>Enlace protegido. Para ver esta remisión necesitas un enlace válido.</h2>';
    exit;
}

$estadoPago = strtolower(trim((string)($pedido['estado_pago'] ?? '')));
if ($estadoPago !== 'pagado') {
    http_response_code(403);
    echo '<h2>Enlace protegido. Para ver esta remisión necesitas un enlace válido.</h2>';
    exit;
}

$detalles = [];
$stD = $conn->prepare("SELECT nombre_producto,talla,color,cantidad,precio,subtotal,imagen,url FROM web_orden_detalle WHERE orden_id=? ORDER BY id ASC");
$ordenId = (int)$pedido['web_orden_id'];
$stD->bind_param('i', $ordenId);
$stD->execute();
$rsD = $stD->get_result();
while ($r = $rsD->fetch_assoc()) $detalles[] = $r;

$logo = '/ventas/logo.png';
$qLogo = $conn->query("SELECT logo FROM configuracion WHERE id=1 LIMIT 1");
if ($qLogo && ($rw = $qLogo->fetch_assoc()) && !empty($rw['logo'])) {
    $logo = '/' . ltrim((string)$rw['logo'], '/');
}
?>
<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Remisión Web</title>
<style>
body{margin:0;background:#050505;color:#111;font-family:Segoe UI,Arial,sans-serif}.wrap{max-width:980px;margin:28px auto;padding:0 14px}.card{background:#fff;border-radius:18px;overflow:hidden;box-shadow:0 18px 40px rgba(0,0,0,.35)}.head{background:#0b0b0f;color:#fff;padding:18px 20px;display:flex;justify-content:space-between;align-items:center}.head img{height:48px;max-width:180px;object-fit:contain}.body{padding:20px;position:relative}.wm{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;opacity:.04;pointer-events:none}.wm img{max-width:60%}.meta{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px;margin-bottom:16px}.box{background:#f7f7f7;border-radius:10px;padding:10px}.table{width:100%;border-collapse:collapse}.table th,.table td{padding:10px;border-bottom:1px solid #e5e5e5;text-align:left}.foot{display:flex;justify-content:space-between;align-items:center;margin-top:16px}.btn{background:#c89b3c;color:#111;padding:10px 14px;border-radius:10px;text-decoration:none;font-weight:700}
</style></head><body><div class="wrap"><div class="card"><div class="head"><div><strong>Remisión Web</strong><div><?= rw_e($pedido['folio'] ?? $pedido['codigo'] ?? 'WEB') ?></div></div><img src="<?= rw_e($logo) ?>" alt="logo"></div><div class="body"><div class="wm"><?php if($logo): ?><img src="<?= rw_e($logo) ?>" alt="wm"><?php endif; ?></div>
<div class="meta">
<div class="box"><strong>Cliente</strong><div><?= rw_e($pedido['cliente_nombre'] ?? '') ?></div></div>
<div class="box"><strong>Teléfono</strong><div><?= rw_e($pedido['cliente_telefono'] ?? '') ?></div></div>
<div class="box"><strong>Correo</strong><div><?= rw_e($pedido['cliente_correo'] ?? '') ?></div></div>
<div class="box"><strong>Dirección / referencia</strong><div><?= rw_e($pedido['cliente_direccion'] ?? '') ?></div></div>
<div class="box"><strong>Fecha</strong><div><?= rw_e($pedido['orden_fecha'] ?? $pedido['created_at'] ?? '') ?></div></div>
<div class="box"><strong>Estado pago</strong><div>pagado/aprobado</div></div>
</div>
<table class="table"><thead><tr><th>Producto</th><th>Talla</th><th>Color</th><th>Cantidad</th><th>Precio</th><th>Subtotal</th></tr></thead><tbody>
<?php foreach($detalles as $d): ?>
<tr><td><?= rw_e($d['nombre_producto'] ?? '') ?></td><td><?= rw_e($d['talla'] ?? '-') ?></td><td><?= rw_e($d['color'] ?? '-') ?></td><td><?= rw_e($d['cantidad'] ?? '1') ?></td><td>$<?= number_format((float)($d['precio'] ?? 0),2) ?></td><td>$<?= number_format((float)($d['subtotal'] ?? 0),2) ?></td></tr>
<?php endforeach; ?>
</tbody></table>
<div class="foot"><strong>Total: $<?= number_format((float)($pedido['total'] ?? 0),2) ?></strong><a href="#" class="btn" onclick="window.print();return false;">Imprimir</a></div>
</div></div></div></body></html>
