<?php
require_once __DIR__ . '/includes/web_helpers.php';
$data = sw_load_data();
$negocio = $data['negocio'] ?? [];
$title = sw_page_title($data, 'Aviso de privacidad');
$nombre = (string)($negocio['nombre'] ?? 'Suave Urban Studio');
$correo = trim((string)($negocio['correo'] ?? ''));
$telefono = trim((string)($negocio['telefono'] ?? ''));
$whatsapp = trim((string)($negocio['whatsapp'] ?? ''));
$direccion = trim((string)($negocio['direccion'] ?? ''));
$custom = trim((string)($data['legales']['aviso_privacidad'] ?? ''));
require __DIR__ . '/includes/web_header.php';
?>
<section class="page-title legal-title">
    <p>Información legal</p>
    <h1>Aviso de privacidad</h1>
    <span>Última actualización: <?= sw_e(date('d/m/Y')) ?></span>
</section>

<section class="clean-panel legal-page">
<?php if ($custom !== ''): ?>
    <div class="legal-content"><?= nl2br(sw_e($custom)) ?></div>
<?php else: ?>
    <p><strong><?= sw_e($nombre) ?></strong>, en adelante “la Tienda”, pone a disposición de sus clientes y visitantes el presente Aviso de Privacidad para explicar de forma clara cómo recopila, usa, conserva y protege los datos personales relacionados con la navegación, registro y compra dentro de la tienda en línea de la marca.</p>

    <h2>1. Responsable del tratamiento de datos</h2>
    <p>El responsable del uso y protección de los datos personales es <strong><?= sw_e($nombre) ?></strong>, tienda dedicada a la venta de productos, prendas y artículos de la marca Suave Urban Studio.</p>
    <?php if ($direccion !== ''): ?><p><strong>Domicilio o zona de atención:</strong> <?= nl2br(sw_e($direccion)) ?></p><?php endif; ?>

    <h2>2. Datos que podemos solicitar</h2>
    <p>Para brindar atención, procesar pedidos y mejorar la experiencia de compra, la Tienda puede solicitar o recibir datos como:</p>
    <ul>
        <li>Nombre completo.</li>
        <li>Teléfono y/o WhatsApp.</li>
        <li>Correo electrónico.</li>
        <li>Dirección de entrega o referencias necesarias para el envío.</li>
        <li>Datos de compra, carrito, productos seleccionados, tallas, colores, cantidades y preferencias de compra.</li>
        <li>Comprobantes, mensajes o información que el cliente proporcione para seguimiento de su pedido.</li>
        <li>Datos fiscales únicamente cuando el cliente solicite factura y resulte aplicable.</li>
    </ul>

    <h2>3. Finalidades principales</h2>
    <p>Los datos personales se utilizan para:</p>
    <ul>
        <li>Crear o administrar la cuenta del cliente.</li>
        <li>Procesar compras, pagos, pedidos y entregas.</li>
        <li>Confirmar disponibilidad de productos, tallas, colores y existencias.</li>
        <li>Contactar al cliente por WhatsApp, teléfono o correo para seguimiento de compra.</li>
        <li>Coordinar envíos, entregas, cambios, aclaraciones o atención posterior a la compra.</li>
        <li>Enviar avisos importantes relacionados con pedidos, promociones, novedades, beneficios o lanzamientos de la marca.</li>
        <li>Mejorar el catálogo, atención al cliente, seguridad y experiencia dentro de la web.</li>
        <li>Cumplir obligaciones administrativas, contables, fiscales o legales cuando corresponda.</li>
    </ul>

    <h2>4. Uso para promociones y comunicación comercial</h2>
    <p>La Tienda podrá contactar al cliente para compartir promociones, novedades, lanzamientos, beneficios o información de la marca, siempre relacionada con los productos y servicios de Suave Urban Studio. El cliente puede solicitar dejar de recibir comunicaciones promocionales por los medios de contacto publicados.</p>

    <h2>5. Transferencias y servicios de terceros</h2>
    <p>La Tienda no vende ni renta datos personales. Los datos pueden compartirse únicamente cuando sea necesario para operar la compra o cumplir obligaciones, por ejemplo con:</p>
    <ul>
        <li>Servicios de paquetería, mensajería o repartidores.</li>
        <li>Proveedores de hosting, almacenamiento, seguridad o administración web.</li>
        <li>Herramientas de comunicación como WhatsApp, correo electrónico u otras plataformas de atención.</li>
        <li>Herramientas de almacenamiento o respaldo como Google Drive, cuando sea necesario para la operación de la tienda.</li>
        <li>Autoridades competentes cuando exista obligación legal.</li>
    </ul>

    <h2>6. Responsabilidad del cliente sobre sus datos</h2>
    <p>El cliente es responsable de proporcionar información completa, correcta y actualizada. La Tienda no será responsable por retrasos, entregas incorrectas, imposibilidad de contacto o problemas derivados de datos erróneos, incompletos o desactualizados proporcionados por el cliente.</p>

    <h2>7. Conservación y seguridad</h2>
    <p>La Tienda conservará los datos durante el tiempo necesario para cumplir las finalidades descritas, atender aclaraciones, conservar historial de pedidos y cumplir obligaciones legales o administrativas. Se aplican medidas razonables de seguridad para proteger la información contra acceso no autorizado, pérdida, alteración o uso indebido.</p>

    <h2>8. Derechos del cliente</h2>
    <p>El cliente puede solicitar acceso, rectificación, cancelación u oposición respecto de sus datos personales, así como revocar su consentimiento para usos no indispensables. Para realizar una solicitud, puede contactar a la Tienda mediante los canales publicados en esta web.</p>

    <h2>9. Cookies y navegación</h2>
    <p>La web puede utilizar cookies o tecnologías similares para recordar preferencias, mejorar la navegación, mantener sesiones, analizar funcionamiento de la tienda y ofrecer una experiencia más útil. El usuario puede administrar cookies desde la configuración de su navegador.</p>

    <h2>10. Cambios al aviso</h2>
    <p>La Tienda puede actualizar este Aviso de Privacidad para reflejar cambios operativos, legales o de funcionamiento. La versión vigente estará disponible en esta página.</p>

    <div class="legal-signature">
        <strong>Firma comercial</strong>
        <p><?= sw_e($nombre) ?></p>
        <span>Tienda oficial de la marca Suave Urban Studio</span>
        <?php if ($correo !== ''): ?><span>Correo: <?= sw_e($correo) ?></span><?php endif; ?>
        <?php if ($telefono !== ''): ?><span>Teléfono: <?= sw_e($telefono) ?></span><?php endif; ?>
        <?php if ($whatsapp !== ''): ?><span>WhatsApp: <?= sw_e($whatsapp) ?></span><?php endif; ?>
    </div>
<?php endif; ?>
</section>

<style>
.legal-title span{display:inline-block;margin-top:10px;color:rgba(255,255,255,.58);font-size:13px}.legal-page{line-height:1.75;color:rgba(255,255,255,.82)}.legal-page h2{margin:28px 0 10px;color:var(--su-gold-soft);font-size:22px}.legal-page p{margin:0 0 14px}.legal-page ul{margin:0 0 16px 22px;padding:0}.legal-page li{margin:7px 0}.legal-signature{margin-top:34px;padding:20px;border:1px solid rgba(212,175,55,.22);border-radius:18px;background:linear-gradient(135deg,rgba(212,175,55,.10),rgba(255,255,255,.025));box-shadow:0 18px 45px rgba(0,0,0,.25)}.legal-signature strong{display:block;color:var(--su-gold);letter-spacing:.08em;text-transform:uppercase;font-size:12px;margin-bottom:10px}.legal-signature p{font-size:22px;font-weight:800;color:#fff;margin:0 0 4px}.legal-signature span{display:block;color:rgba(255,255,255,.68);font-size:14px;margin-top:4px}.legal-content{white-space:normal}
</style>
<?php require __DIR__ . '/includes/web_footer.php'; ?>
