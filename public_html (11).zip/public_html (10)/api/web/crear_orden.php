<?php
declare(strict_types=1);

require_once __DIR__ . '/web_order_service.php';

function woc_resp(int $status, array $payload): void {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function woc_log(string $line): void {
    @file_put_contents(__DIR__ . '/debug_crear_orden.log', '[' . date('c') . '] ' . $line . PHP_EOL, FILE_APPEND);
}

woc_log('REQUEST START');
woc_log('method=' . ($_SERVER['REQUEST_METHOD'] ?? ''));
woc_log('origin=' . ($_SERVER['HTTP_ORIGIN'] ?? ''));
woc_log('content_type=' . ($_SERVER['CONTENT_TYPE'] ?? ($_SERVER['HTTP_CONTENT_TYPE'] ?? '')));

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    woc_log('error=Metodo no permitido');
    woc_resp(405, ['ok' => false, 'mensaje' => 'Método no permitido']);
}

$raw = (string)file_get_contents('php://input');
woc_log('body_raw=' . $raw);
$input = json_decode($raw, true);
if (!is_array($input)) {
    woc_log('error=JSON invalido');
    woc_resp(400, ['ok' => false, 'mensaje' => 'JSON inválido']);
}

if (!isset($conn) || !($conn instanceof mysqli)) {
    woc_log('error=Conexion no disponible');
    woc_resp(500, ['ok' => false, 'mensaje' => 'Conexión no disponible']);
}

try {
    $result = woc_create_order($conn, $input);
    woc_log('success=' . json_encode($result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    woc_resp(201, $result);
} catch (Throwable $e) {
    woc_log('error=' . $e->getMessage());
    woc_resp(422, ['ok' => false, 'mensaje' => $e->getMessage()]);
}
