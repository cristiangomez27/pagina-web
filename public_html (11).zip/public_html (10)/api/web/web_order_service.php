<?php
declare(strict_types=1);

require_once __DIR__ . '/../../ventas/config/database.php';

function woc_clean_text($value, int $max = 255): string {
    $txt = trim((string)$value);
    if ($txt === '') return '';
    return mb_substr($txt, 0, $max, 'UTF-8');
}

function woc_clean_money($value): float {
    $n = is_numeric($value) ? (float)$value : 0.0;
    return $n < 0 ? 0.0 : round($n, 2);
}

function woc_clean_qty($value): int {
    $q = (int)$value;
    return max(1, min(9999, $q));
}

function woc_clean_image_url($value): string {
    $raw = trim((string)$value);
    if ($raw === '') return '';
    if (preg_match('~^https?://~i', $raw)) {
        $raw = (string)parse_url($raw, PHP_URL_PATH);
    }
    $raw = '/' . ltrim(str_replace('\\', '/', $raw), '/');
    if (preg_match('~^/(ventas/uploads|uploads|assets)/~i', $raw)) {
        return str_starts_with($raw, '/uploads/') ? '/ventas' . $raw : $raw;
    }
    return '';
}

function woc_find_or_create_cliente(mysqli $conn, array $cliente): ?int {
    $nombre = woc_clean_text($cliente['nombre'] ?? '', 180);
    $telefono = preg_replace('/\D+/', '', (string)($cliente['telefono'] ?? ''));
    $correo = mb_strtolower(woc_clean_text($cliente['correo'] ?? '', 190), 'UTF-8');
    $direccion = woc_clean_text($cliente['direccion'] ?? '', 255);
    $uid = woc_clean_text($cliente['web_cliente_uid'] ?? '', 80);

    if ($uid !== '') {
        $st = $conn->prepare("SELECT id FROM clientes WHERE web_cliente_uid = ? LIMIT 1");
        if ($st) { $st->bind_param('s', $uid); $st->execute(); $rs = $st->get_result(); if ($r = $rs->fetch_assoc()) return (int)$r['id']; }
    }
    if ($correo !== '') {
        $st = $conn->prepare("SELECT id FROM clientes WHERE email = ? LIMIT 1");
        if ($st) { $st->bind_param('s', $correo); $st->execute(); $rs = $st->get_result(); if ($r = $rs->fetch_assoc()) return (int)$r['id']; }
    }
    if ($telefono !== '') {
        $st = $conn->prepare("SELECT id FROM clientes WHERE telefono = ? LIMIT 1");
        if ($st) { $st->bind_param('s', $telefono); $st->execute(); $rs = $st->get_result(); if ($r = $rs->fetch_assoc()) return (int)$r['id']; }
    }

    $tipo = 'general'; $origen = 'web_publica'; $activo = 1;
    $st = $conn->prepare("INSERT INTO clientes (nombre, telefono, email, direccion, tipo_cliente, origen, web_cliente_uid, activo, fecha_registro) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())");
    if (!$st) return null;
    $st->bind_param('sssssssi', $nombre, $telefono, $correo, $direccion, $tipo, $origen, $uid, $activo);
    if (!$st->execute()) return null;
    return (int)$conn->insert_id;
}

function woc_create_order(mysqli $conn, array $input): array {
    $cliente = is_array($input['cliente'] ?? null) ? $input['cliente'] : [];
    $items = is_array($input['carrito'] ?? null) ? $input['carrito'] : [];
    if (!$items) throw new RuntimeException('Carrito vacío.');

    $nombre = woc_clean_text($cliente['nombre'] ?? '', 180);
    $telefono = preg_replace('/\D+/', '', (string)($cliente['telefono'] ?? ''));
    if ($nombre === '' || $telefono === '') throw new RuntimeException('Nombre y teléfono son obligatorios.');

    $correo = mb_strtolower(woc_clean_text($cliente['correo'] ?? '', 190), 'UTF-8');
    $direccion = woc_clean_text($cliente['direccion'] ?? '', 255);
    $notas = woc_clean_text($cliente['notas'] ?? '', 500);
    $uid = woc_clean_text($cliente['web_cliente_uid'] ?? '', 80);

    $rows = []; $total = 0.0;
    foreach ($items as $it) {
        if (!is_array($it)) continue;
        $qty = woc_clean_qty($it['qty'] ?? 1);
        $price = woc_clean_money($it['price'] ?? 0);
        $subtotal = round($qty * $price, 2);
        $rows[] = [
            'producto_id' => (isset($it['id']) && is_numeric($it['id'])) ? (int)$it['id'] : null,
            'nombre' => woc_clean_text($it['name'] ?? 'Producto', 220),
            'talla' => woc_clean_text($it['size'] ?? '', 80),
            'color' => woc_clean_text($it['color'] ?? '', 120),
            'cantidad' => $qty,
            'precio' => $price,
            'subtotal' => $subtotal,
            'imagen_url' => woc_clean_image_url($it['image'] ?? ''),
            'url' => woc_clean_text($it['url'] ?? '', 255),
            'raw' => $it,
        ];
        $total += $subtotal;
    }
    if (!$rows) throw new RuntimeException('Carrito sin productos válidos.');

    $codigo = 'WEB-' . date('Ymd-His') . '-' . strtoupper(bin2hex(random_bytes(2)));
    $folio = 'PWEB-' . date('YmdHis') . '-' . strtoupper(bin2hex(random_bytes(2)));
    $estado = 'pendiente_pago';
    $clienteId = woc_find_or_create_cliente($conn, $cliente);

    $conn->begin_transaction();
    try {
        $payload = json_encode($input, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $moneda = 'MXN';
        $estadoPago = 'pendiente';
        $procesado = 0;

        $st = $conn->prepare("INSERT INTO web_ordenes (codigo, cliente_id, web_cliente_uid, cliente_nombre, cliente_telefono, cliente_correo, cliente_direccion, cliente_notas, total, moneda, estado, estado_pago, procesado, payload_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
        $st->bind_param('sissssssdsssis', $codigo, $clienteId, $uid, $nombre, $telefono, $correo, $direccion, $notas, $total, $moneda, $estado, $estadoPago, $procesado, $payload);
        if (!$st->execute()) throw new RuntimeException('No se pudo guardar web_orden.');
        $webOrdenId = (int)$conn->insert_id;

        $stP = $conn->prepare("INSERT INTO pedidos_web (web_orden_id, cliente_id, folio, estado, subtotal, envio, descuento, total, moneda, metodo_pago, referencia_pago, canal, notas_internas, created_at) VALUES (?, ?, ?, ?, ?, 0, 0, ?, ?, NULL, NULL, 'web', NULL, NOW())");
        $stP->bind_param('iissdds', $webOrdenId, $clienteId, $folio, $estado, $total, $total, $moneda);
        if (!$stP->execute()) throw new RuntimeException('No se pudo guardar pedidos_web.');
        $pedidoWebId = (int)$conn->insert_id;

        $stD1 = $conn->prepare("INSERT INTO web_orden_detalle (orden_id, producto_id, nombre_producto, talla, color, cantidad, precio, subtotal, imagen, url, metadata_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
        $stD2 = $conn->prepare("INSERT INTO pedidos_web_detalle (pedido_web_id, web_orden_detalle_id, producto_id, sku, nombre_producto, talla, color, cantidad, precio_unitario, subtotal, imagen_url, metadata_json, created_at) VALUES (?, ?, ?, NULL, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");

        foreach ($rows as $r) {
            $meta = json_encode($r['raw'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            $stD1->bind_param('iisssiddsss', $webOrdenId, $r['producto_id'], $r['nombre'], $r['talla'], $r['color'], $r['cantidad'], $r['precio'], $r['subtotal'], $r['imagen_url'], $r['url'], $meta);
            if (!$stD1->execute()) throw new RuntimeException('No se pudo guardar web_orden_detalle.');
            $webOrdenDetalleId = (int)$conn->insert_id;

            $stD2->bind_param('iiisssiddss', $pedidoWebId, $webOrdenDetalleId, $r['producto_id'], $r['nombre'], $r['talla'], $r['color'], $r['cantidad'], $r['precio'], $r['subtotal'], $r['imagen_url'], $meta);
            if (!$stD2->execute()) throw new RuntimeException('No se pudo guardar pedidos_web_detalle.');
        }

        $tipo = 'orden_creada';
        $msg = 'Orden web creada en estado pendiente_pago.';
        $ev = json_encode(['codigo' => $codigo, 'estado' => $estado, 'total' => $total], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $stE = $conn->prepare("INSERT INTO pedidos_web_eventos (pedido_web_id, tipo, mensaje, payload_json, created_at) VALUES (?, ?, ?, ?, NOW())");
        $stE->bind_param('isss', $pedidoWebId, $tipo, $msg, $ev);
        if (!$stE->execute()) throw new RuntimeException('No se pudo guardar pedidos_web_eventos.');

        $conn->commit();
        return ['ok' => true, 'orden' => ['id' => $webOrdenId, 'pedido_web_id' => $pedidoWebId, 'codigo' => $codigo, 'folio' => $folio, 'estado' => $estado, 'total' => $total]];
    } catch (Throwable $e) {
        $conn->rollback();
        throw $e;
    }
}
