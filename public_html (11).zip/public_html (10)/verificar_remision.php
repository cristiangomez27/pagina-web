<?php
declare(strict_types=1);

$token = trim((string)($_GET['token'] ?? $_GET['t'] ?? ''));
$query = $token !== '' ? ('?t=' . urlencode($token)) : '';
header('Location: /ventas/verificar_remision.php' . $query, true, 302);
exit;
