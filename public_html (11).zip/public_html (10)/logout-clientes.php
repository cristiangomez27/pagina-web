<?php
require_once __DIR__ . '/includes/web_helpers.php';
sw_client_logout();
header('Location: /login-clientes?saliste=1');
exit;
